#!/bin/bash
#chma='(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.26.15.25)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=EPDB)))'
#user='VGREGION'
#pass='celare365dies'
. ../src/vgr-db-access.txt
#
list=$(sqlplus -s $USER/$PASS@$EPDB24S << EOF
    set feedback off
    set linesize 500
    set pages 0
    set space 0
    set echo off
    set trimspool on
    set pagesize 0
    set colsep '|'  
#    spool ../output/vgr3.txt 
    select O.ORDERDID,O.ID from ORTORDER O where O.id like '%OR%' and O.CREATEDATE > DATE '2014-09-19';
#    spool off
    exit;
EOF
)
#
#
$count > ../output/vgr5.txt
#echo $USER
#echo $PASS
#echo $EPDB24S
#echo $list > ../output/vgr4.txt
#
