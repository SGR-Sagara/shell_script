#!/bin/bash
#
. ../sql/vvgr-db-order-list.sh
. ../src/vgr-db-access.txt
#
#
VgrDBOrderList '2014/09/24 16:45:01' '2014/09/24 17:45:01'

